import "../styles/DonutBanner.css";

function DonutBanner() {
  return (
    <section className="donut-banner">
        <div className="banner-text">
          <h2>CHOOSE YOUR DONUT!</h2>
          <p>We have everything that will satisfy your cravings!</p>
        </div>

       
    </section>
  );
}

export default DonutBanner;
